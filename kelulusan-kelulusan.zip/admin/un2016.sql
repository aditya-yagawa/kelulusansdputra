-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Bulan Mei 2020 pada 15.51
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `un2016`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `un_konfigurasi`
--

CREATE TABLE `un_konfigurasi` (
  `id` int(11) NOT NULL,
  `sekolah` varchar(255) NOT NULL,
  `tahun` year(4) NOT NULL,
  `tgl_pengumuman` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `un_konfigurasi`
--

INSERT INTO `un_konfigurasi` (`id`, `sekolah`, `tahun`, `tgl_pengumuman`) VALUES
(2, 'SD PUTRA', 2020, '2020-05-10 09:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `un_siswa`
--

CREATE TABLE `un_siswa` (
  `no_ujian` varchar(12) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `n_bin` double NOT NULL,
  `n_mat` double NOT NULL,
  `n_big` double NOT NULL,
  `n_agama` double NOT NULL,
  `n_pkn` double NOT NULL,
  `n_ips` double NOT NULL,
  `n_sbdp` double NOT NULL,
  `n_pjok` double NOT NULL,
  `n_ipa` double NOT NULL,
  `n_tik` double NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `un_siswa`
--

INSERT INTO `un_siswa` (`no_ujian`, `nama`, `kelas`, `n_bin`, `n_mat`, `n_big`, `n_agama`, `n_pkn`, `n_ips`, `n_sbdp`, `n_pjok`, `n_ipa`, `n_tik`, `status`) VALUES
('23-101-463-2', 'Akhdan Daffa Muhammad', '6A', 7, 8, 6, 8.5, 8, 8, 8, 8, 8, 8, 1),
('23-101-464-9', 'Arshavindra Divyaprakash Azizi', '6A', 8.5, 6.4, 8.3, 9, 7, 7, 7, 7, 7, 7, 1),
('23-101-465-8', 'Audya Maheira Rindriastari', '6A', 3.8, 2.2, 3.5, 2, 7, 7, 7, 7, 8, 9, 1),
('23-101-466-7', 'Endhassya Ghina Nurazkiah', '6A', 7, 8, 3, 2, 7, 7, 7, 7, 8, 9, 1),
('23-101-467-6', 'Erlangga Altareja Lazuardi', '6A', 5, 6, 4, 5, 7, 7, 7, 7, 8, 9, 1),
('23-101-468-5', 'Faza Nabil Albari', '6A', 7, 3, 4, 8, 7, 7, 7, 7, 8, 9, 1),
('23-101-469-4', 'Kafka Alyssia Khairani', '6A', 3, 3, 4, 4, 7, 7, 7, 7, 8, 9, 1),
('23-101-470-3', 'Kezia Naurah Prasetiyo', '6A', 6, 4, 2, 4, 7, 7, 7, 7, 8, 9, 1),
('23-101-471-2', 'Kian Haikal Kinanta', '6A', 5, 4, 6, 5, 7, 7, 7, 7, 8, 9, 1),
('23-101-472-9', 'Lyra Carissa Putri', '6A', 7, 4, 4, 6, 7, 7, 7, 7, 8, 9, 1),
('23-101-473-8', 'Mirza Suherman Putro', '6A', 80, 90, 90, 87, 85, 89, 90, 90, 90, 80, 1),
('23-101-474-7', 'Mohamad Wiranata Muhidin', '6A', 8, 6, 5, 2, 7, 7, 7, 7, 8, 9, 1),
('23-101-475-6', 'Muhammad Daffi Athayya Rizqullah', '6A', 7, 7, 6, 4, 7, 7, 7, 7, 8, 9, 1),
('23-101-476-5', 'Muhammad Farrel Akbar', '6A', 6, 2, 8, 8, 7, 7, 7, 7, 8, 9, 1),
('23-101-477-4', 'Neisya Azzahra', '6A', 7, 4, 7, 7, 7, 7, 7, 7, 8, 9, 1),
('23-101-478-3', 'Patricia Aila Zahra Rahindra', '6A', 6, 7, 6, 8, 7, 7, 7, 7, 8, 9, 1),
('23-101-479-2', 'Qirana Mahya Farras Rachmadan', '6A', 4, 8, 6, 3, 7, 7, 7, 7, 8, 9, 1),
('23-101-480-1', 'Rio Tamajiro', '6A', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('23-101-480-9', 'Reva Arthamevia Dwiantaru', '6A', 5, 5, 4, 3, 7, 7, 7, 7, 8, 9, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `un_user`
--

CREATE TABLE `un_user` (
  `UID` tinyint(4) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `un_user`
--

INSERT INTO `un_user` (`UID`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `un_konfigurasi`
--
ALTER TABLE `un_konfigurasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `un_siswa`
--
ALTER TABLE `un_siswa`
  ADD PRIMARY KEY (`no_ujian`);

--
-- Indeks untuk tabel `un_user`
--
ALTER TABLE `un_user`
  ADD PRIMARY KEY (`UID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `un_konfigurasi`
--
ALTER TABLE `un_konfigurasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `un_user`
--
ALTER TABLE `un_user`
  MODIFY `UID` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
